
<html>
<head>

	<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">
<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>

<img src="onlinelabour-header.jpg" height="110" width="1220">

<center>
  
	

   <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="http://localhost/myfolder/labourhomepage.php">Home</a></div>

  			<ul class="nav navbar-nav">
  				<li class="active">
  				<li><a href="#">instruction</a></li>
  				<li><a href="#">Notification </a></li>
  				<li><a href="#">Downloads</a></li>
  				<li><a href="http://localhost/myfolder/labourapplicationstatus.php">Application Status</a></li>
  				<li><a href="http://localhost/myfolder/labourpayment.php">Payment Verification</a></li>
  				<li><a href="http://localhost/myfolder/labouronlinepayment.php">Online Payment</a></li>
  				<li><a href="#">View Cirtificate</a></li>
  				<li><a href="http://localhost/myfolder/labourloginform.php">Login</a></li>
  				<li><a href="http://localhost/myfolder/labournewregister.php"> New User Login</a></li></ul></div></nav>


	
		<font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 
	<body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
	<div>
		<h4>upload your aadarcard(in.doc/.docx/.pdf File Format )Here</h4>
		<table border="1" cellpadding="4" cellspacing="5" style="border-radius:10px 10px 10px 10px;background-color:lime">
			<tr><td>select a file to uplaod:</td>
			<tr><td><form action="labourupload.php" method="post" enctype="multipart/form-data"></td>
			<tr><td><input type="file" name="file" size="50"></td>
			<td><input type="submit" value="upload File"></td></tr></table>
		
	</div></form></body>



</html>


