<html>


<head>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  

<img src="onlinelabour-header.jpg" height="110" width="1220">


<center>
<style>
            .menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="menu">Home</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourhomepage.php">home</a>

</div></nav>




            <style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Instuction</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/Sakala%20-%20Workflow.pdf">sakala workflow</a>

</div></div></nav>

         

 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Notification</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/cla%20notification%20LD%20267%20LET%202016%20dt_20.09.16.pdf">Online Notification</a>

</div></div></nav>



 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Downloads</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


        

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Application Status</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourapplicationstatus.php">Click Here For Application status </a>
 <a href="#">Form</a>
</div></div></nav>



          

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Payment Verification</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourpayment.php">Click Here For Payment Verification </a>
 <a href="#">Form</a>
</div></div></nav>



<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Online Payment</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labouronlinepayment.php">Click Here For Online Payment </a>
 <a href="#">Form</a>
</div></div></nav>


          
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">View Cirtificate</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">Login</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourloginform.php">login</a>
 
</div></div></nav>




<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="menu">New User Login</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labournewregister.php">Create New Account</a>
 
</div></div></nav>


          


  
    <font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 
      <body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
  
    
  </font></center></head>
