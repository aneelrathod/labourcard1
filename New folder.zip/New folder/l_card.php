<html>
<head>



	<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">
<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>

<img src="onlinelabour-header.jpg" height="110" width="1220">

<center>
  
	<style>


            .menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="btn btn-primary"><a href="http://localhost/myfolder/labourhomepage.php"><font color="white">home</a></button>
<div class="submenu-content">
  

</div></nav>




            <style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Instuction</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/Sakala%20-%20Workflow.pdf">sakala workflow</a>

</div></div></nav>

         

 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Notification</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/cla%20notification%20LD%20267%20LET%202016%20dt_20.09.16.pdf">Online Notification</a>

</div></div></nav>



 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Downloads</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


        

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Application Status</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourapplicationstatus.php">Click Here For Application status </a>
 <a href="#">Form</a>
</div></div></nav>



          

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Payment Verification</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourpayment.php">Click Here For Payment Verification </a>
 <a href="#">Form</a>
</div></div></nav>



<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Online Payment</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labouronlinepayment.php">Click Here For Online Payment </a>
 <a href="#">Form</a>
</div></div></nav>


          
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">View Cirtificate</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>

<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labourloginform.php"><font color="white">login</font></a></button>
 





<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}



#tab{border-radius: 10px; background-image: linear-gradient(to right,steelblue,white); width: 700px; height: 500px}
</style>




<button class="btn btn-primary"><a href="http://localhost/myfolder/labournewregister.php"><font color="white">New User Login</a></button>

  
</nav>


   
		<font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 


	<script type="text/javascript">
		
		function chk()
		{
		

		if(document.f1.t1.value=="")
		{
			alert("enter your name");
		}
		else if(document.f1.t2.value=="")
		{
			alert("enter your last name");
		}
else if(document.f1.t3.value=="")
{
	alert("enter your DOB");
		}

		else if(document.f1.gen.value=="")
		{
			alert("enter your gender")
		}
else if(document.f1.Pension.value=="")
{
	alert("Already Pension Availed From Any Govt Dept click yes or no");
}
		else if(document.f1.t4.value=="")
		{
			alert("enter your mobile number");
		}

		else if(document.f1.t5.value=="")
		{
			alert("enter your Aadar card number");

		}
		else if(document.f1.state.value=="")
		{
			alert("select your state");
		}
		else if(document.f1.district.value=="")
		{
			alert("select your district");
		}
		else if(document.f1.taluka.value=="")
		{
			alert("select your taluka");
		}
		else if(document.f1.grampanchyat.value=="")
		{
			alert("select your grampanchyat");
		}
		else if(document.f1.village.value=="")
{
	alert("select your village");
}
else if(document.f1.t6.value=="")
{
	alert("Please enter bank name");
}
else if (document.f1.t7.value=="")
{
	alert("Please enter your bank Account number");
}
else if(document.f1.t8.value=="")
{
	alert("enter your bank IFSC code");


}
else if(document.f1.iagree.value=="")
{
	alert("Please click above information is ok");
}
}

	</script>

</head>

<body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">



	<form name="f1" action="l_card.php" method="POST">

	<div id='tab'><table border="0" cellpadding="1" cellspacing="1">
		
		
		<tr><td>Name of the benificery :</td>
			<td><input type="text" name="t1"></td></tr>
			<tr><td>Last name of the benificery :</td>
				<td><input type="text" name="t2"></td></tr>
				<tr><td>Benificery Date of Birth :</td>
					<td><input type="text" name="t3"></td></tr>
					<tr><td>Gender :</td>
						<td>

							<input type="radio" name="gen" value="male">Male
							<input type="radio" name="gen" value="Female">Female</td></tr>
					<tr><td>Already Pension Availed From Any Govt Dept :</td>
						<td><input type=radio name="Pension" value="yes">yes
							<input type=radio name="Pension" value="no">no</td></tr>
						<tr><td> Benificery Mobile Number :</td>
							<td><input type="number" name="t4"></td></tr>
							<tr><td>Benificery Addar card Number :</td>
								<td><input type="number" name="t5"></td></tr>
							<tr><td>State:</td>
								<td><select name="state" required="">
									<option>
									<option>karnataka
										<option>mumbai
											<option>chennai
								</select></td></tr>
								<tr><td>District:</td>
								<td><select name="district" required="">
									<option>
									<option>gulbarga
										<option>bangalore
											<option>mysore
								</select></td></tr>

								<tr><td>Taluka:</td>
								<td><select name="taluka" required="">
									<option>
									<option>chitapur
										<option>chincholli
											<option>jewargi
								</select></td></tr>

								<tr><td>Grampanchyat:</td>
								<td><select name="grampanchyat" required="">
							
									<option>
										<option>sannur
											<option>madbooll
												<option>kusnoor
								</select></td></tr>

								<tr><td>Village:</td>
								<td><select name="village" required="">
									<option>
									<option>saradgi
										<option>palla
											<option>bollewad
								</select></td></tr>
<tr><td>Bank Name :</td>
	<td><input type="text" name="t6" required></td></tr>
		<tr><td>Bank Account Number :</td>
			<td><input type="number" name="t7" required></td></tr>
			<tr><td>Bnak IFSC CODE :</td>
				<td><input type="text" name="t8" required></td></tr>
				
				<tr><td>Diclaration :</td>
					<td><pre>the fact mentioned above are true to the best<p>of my knowledge andinformation.<input type="checkbox" name="iagree" required> I Agree</td>

				</tr>
                           




								<tr style="background-color:#4fffb8"><td colspan="2"><center><input type="submit" class="btn btn-primary" name="b1" value="Submit" onclick="chk()">
									<input type="reset" class="btn btn-danger" name="reset" value="Reset"></td></tr>







	</table>

  


<button type="button" class="btn btn-warning">Temproray save</button>
<button type="button" class="btn btn-success"><a href="http://localhost/myfolder/labouronlinepayment.php"><font color="white">Continue For Payment</button>

<button type="button" class="btn btn-warning"><a href="http://localhost/myfolder/labourapplicationstatus.php">Print</a></button>



</form>

</body>

</html>
<?php
if(isset($_POST['b1']))
{

	$con=mysqli_connect("localhost","root","","labour_card");

	if(mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL:".mysqli_connect_error();
	}
	$sql="INSERT INTO l_card(name,lastname,dob,gender,APAfromanygovt,mobile,aadarcardnumber,state,District,Taluka,grampanchyat,village,Bankname,Bankaccountnumber,BankIFSCCode,Diclaration)values('$_POST[t1]','$_POST[t2]','$_POST[t3]','$_POST[gen]','$_POST[Pension]','$_POST[t4]','$_POST[t5]','$_POST[state]','$_POST[district]','$_POST[taluka]','$_POST[grampanchyat]','$_POST[village]','$_POST[t6]','$_POST[t7]','$_POST[t8]','$_POST[iagree]')";

if(!mysqli_query($con,$sql))
{
	die('error:'.mysqli_error());

}

echo "<b>","<u>","<font color=blue font size=4> Record Succesfully Added";

mysqli_close($con);
}
?>
<h4>Note: Labour Department is not responsible for your Uploaded Files. Please Check before Uploading your Files.</h4>
<a href="http://localhost/myfolder/labouraddarfileupload.php"><button type= button class="btn btn-warning"><font color="white">Click Here and upload your aadarcard</a>


	