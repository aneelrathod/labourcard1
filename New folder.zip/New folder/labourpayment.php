<html>
<head>
	<center>
	

	<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">
<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>

<img src="onlinelabour-header.jpg" height="110" width="1220">

<center>
  

<style>
            .menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="btn btn-primary"><a href="http://localhost/myfolder/labourhomepage.php"><font color="white">home</a></button>
<div class="submenu-content">
  

</div></nav>




            <style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Instuction</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/Sakala%20-%20Workflow.pdf">sakala workflow</a>

</div></div></nav>

         

 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Notification</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/cla%20notification%20LD%20267%20LET%202016%20dt_20.09.16.pdf">Online Notification</a>

</div></div></nav>



 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Downloads</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


        

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Application Status</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourapplicationstatus.php">Click Here For Application status </a>
 <a href="#">Form</a>
</div></div></nav>



          

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Payment Verification</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourpayment.php">Click Here For Payment Verification </a>
 <a href="#">Form</a>
</div></div></nav>



<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Online Payment</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labouronlinepayment.php">Click Here For Online Payment </a>
 <a href="#">Form</a>
</div></div></nav>


          
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">View Cirtificate</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>

<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labourloginform.php"><font color="white">login</font></a></button>
 





<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="btn btn-primary"><a href="http://localhost/myfolder/labournewregister.php"><font color="white">New User Login</a></button>

  
</nav>



	<font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 
	<body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
	


<body>
<HR COLOR="YELLOW">
	<form name=f1 action="labourpayment.php" method="POST">
		Enter Aadhar Number:<input type=text name=t9 required>
		<button class="btn btn-warning" name=b1>find</button>click here and check the amount paid or not!
	</form>
	
	
</body>
</html>

<?php

if(isset($_POST['b1']))
{
	$aadarcardnumber=$_POST['t9'];
	
	$con=mysqli_connect("localhost","root","","labour_card");

	if(mysqli_connect_errno())
	{
		echo "failed to connect to MySQL:".mysqli_connect_error();
	}
	$result=mysqli_query($con,"SELECT * FROM labourpayment WHERE aadarcardnumber='$aadarcardnumber'");

	
		echo "<table style='border:5px double silver;'>";
			
	while($row=mysqli_fetch_array($result))
	{
		
		
		echo "<tr><td><b>Aadar card Number:</b>".$row['aadarcardnumber']."</td></tr><tr><td><b>Payment:</b>".$row['payment']."</td></tr>";
		
echo"<tr><td>Your Payment Was Succesfully Done!</td></tr>";
echo "<tr><td colspan='2'><center><input type=button name='Print/Downloads' value='Print/Downloads' onclick='window.print()'>";	
 echo "</table>";


        
		}
		}
		?>
	