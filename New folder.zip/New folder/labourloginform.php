<?php
session_start();
?>
<html>


<head>

	<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">
<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>

<img src="onlinelabour-header.jpg" height="110" width="1220">

<center>
  
	

   <style>
            .menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="btn btn-primary"><a href="http://localhost/myfolder/labourhomepage.php"><font color="white">home</a></button>
<div class="submenu-content">
  

</div></nav>




            <style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Instuction</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/Sakala%20-%20Workflow.pdf">sakala workflow</a>

</div></div></nav>

         

 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Notification</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/cla%20notification%20LD%20267%20LET%202016%20dt_20.09.16.pdf">Online Notification</a>

</div></div></nav>



 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Downloads</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


        

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Application Status</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourapplicationstatus.php">Click Here For Application status </a>
 <a href="#">Form</a>
</div></div></nav>



          

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Payment Verification</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourpayment.php">Click Here For Payment Verification </a>
 <a href="#">Form</a>
</div></div></nav>



<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Online Payment</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labouronlinepayment.php">Click Here For Online Payment </a>
 <a href="#">Form</a>
</div></div></nav>


          
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">View Cirtificate</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>

<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labourloginform.php"><font color="white">login</a></button>
 





<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}
#tab{border-radius: 10px; background-image: linear-gradient(to right,steelblue,white); width: 350px; height: 190px}


</style>


<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labournewregister.php"><font color="white">New User Login</font></a></button>

	
		<font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 
	<body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
	



	<center><div id='tab'> <table border="0" cellpadding="1" cellspacing="1" bgcolor="lime" style="border-radius: 10px 10px 10px 10px ">
	<center><font size=5 color=red><b>Login Here<b>
	<form name="form" method="POST" action="labourloginform.php">
		<tr><td><font color=>Enter User Name</td><td><input type="text" name="t1" autofocus></td></tr>
		<tr><td>Enter password</td><td><input type="password" name="pass" value=""></td></tr>
		<tr><td colspan="2"><center><button class="btn btn-warning" value="login" name="login">Login</button></td></tr>
	</form>
</table>
</body>
</html>
<?php
$con=mysqli_connect('localhost','root','','college_mgt');
if(isset($_POST['login']))
{
	$user_name=$_POST['t1'];
	$user_pass=$_POST['pass'];
	$check_user="select * from usernamepass1 where username='$user_name' AND password='$user_pass'";
	$run=mysqli_query($con,$check_user);
	if(mysqli_num_rows($run))
	{
		echo "<script> window.open('l_card.php','_self')</script>";
		$_SESSION['name']=$user_name;

	}
	else
	{
		echo "<script> alert('name or password is incorrect ! ')</script>";

	}
}
	
?>











