<html>
 
<head>

	<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="bootstrap-3.3.7/dist/css/bootstrap-theme.css">
<script src="bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>

<img src="onlinelabour-header.jpg" height="110" width="1220">

<center>
  
	

   <style>
            .menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="btn btn-primary"><a href="http://localhost/myfolder/labourhomepage.php"><font color="white">home</a></button>
<div class="submenu-content">
  

</div></nav>




            <style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Instuction</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/Sakala%20-%20Workflow.pdf">sakala workflow</a>

</div></div></nav>

         

 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Notification</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/cla%20notification%20LD%20267%20LET%202016%20dt_20.09.16.pdf">Online Notification</a>

</div></div></nav>



 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Downloads</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


        

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Application Status</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourapplicationstatus.php">Click Here For Application status </a>
 <a href="#">Form</a>
</div></div></nav>



          

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Payment Verification</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourpayment.php">Click Here For Payment Verification </a>
 <a href="#">Form</a>
</div></div></nav>



<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Online Payment</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labouronlinepayment.php">Click Here For Online Payment </a>
 <a href="#">Form</a>
</div></div></nav>


          
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">View Cirtificate</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>


<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labourloginform.php"><font color="white">login</font></a></button>
 




<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}

#tab{border-radius: 10px; background-image: linear-gradient(to right,steelblue,white); width: 400px; height: 150px}
</style>

<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labournewregister.php"><font color="white">New User Login</a></font></button>
 


	
		<font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 
	<body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
	<div>


	<form action="" method="POST">
		<div id='tab'><table border=0 cellpadding="1" cellspacing="1" style="border-radius: 10px 10px 10px 10px ">
			<tr>
				<td>user name</td>
				<td><input type="text" name="username" placeholder="username" required/></td></tr>
				<tr>
					<td>password</td>
				<td><input id="password" name="password" type="password" placeholder="password" required/></td></tr>
				<tr><td>confirm password</td>
					<td><input id="confirmpassword" name="confirmpassword"type="password" placeholder ="confirm password"required/></td></tr>
					<tr><td>Mobile number:</td>
					<td><input type="text" name="t1" placeholder="mobile number" required></td></tr>
					<tr><td colspan="2"><center><input type="submit" name="submit" value="register" style="border-radius: 10px 10px 10px; background-color:skyblue  "> </td></tr></table></form></body></html>


<?php
require('config.php');

if(isset($_POST['username']) && isset($_POST['password']))
{
	$username=$_POST['username'];
	$password=$_POST['password'];
	$cpassword=$_POST['confirmpassword'];
	$mobile=$_POST['t1'];

	$slquery="SELECT 1 FROM usernamepass1 WHERE username='$username'";
	$selectresult=mysqli_query($con,$slquery);

	if(mysqli_num_rows($selectresult)>0)

	{
		$msg='User Already Exists';
		echo "<h1 style='background:orange;color:white'>",$msg,"</h1>";
	}
else
{
	$query="INSERT INTO usernamepass1(username,password,mobile) VALUES ('$username','$password','$mobile')";
	$result=mysqli_query($con,$query);
	if($result)
	{
		$msg="User Created Successfully.";
		echo "<h3 style='background:green; color:white'>",$msg,"</h3>";

echo "Enter OTP:<input type=text name=t9 placeholder='OTP'  required>
		<button class='btn btn-warning' name=b1><a href='http://localhost/myfolder/l_card.php'>send</a></button>";

	
	}
}
}
?>




