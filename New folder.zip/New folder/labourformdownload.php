
<html>

<head>

	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	

<img src="onlinelabour-header.jpg" height="110" width="1220">

  
	

   <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
    	

<ul class="nav navbar-nav">
  				<li class="active">

      <a class="navbar-brand" href="http://localhost/myfolder/labourhomepage.php">Home</a>
                <li><a href="#">instruction</a></li>
  				<li><a href="#">Notification </a></li>
   
  				<li><a href="http://localhost/myfolder/labourapplicationstatus.php">Application Status</a></li>
  				<li><a href="http://localhost/myfolder/labourpayment.php">Payment Verification</a></li>
  				<li><a href="http://localhost/myfolder/labouronlinepayment.php">Online Payment</a></li>
  				<li><a href="#">View Cirtificate</a></li>
  				<li><a href="http://localhost/myfolder/labourloginform.php">Login</a></li>
  				<li><a href="http://localhost/myfolder/labournewregister.php"> New User Login</a></li>

    
<div class="container">
  <div class="dropdown">
    		<button class="btn dropdown-toggle" type="button" data-toggle="dropdown"><li><a href="#">download</a></li>
      <span class="caret"></span></button>
      <ul class="dropdown-menu">
      <li><a href="#">Link 1</a></li>
      <li><a href="#">Link 2</a></li>
      <li><a href="#">Link 3</a></li></ul></div></div></li>
  </ul></div></div></nav>
  </head>
 
      
		
	<body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
	

<font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2022(Alredy you have registerd go to login form)</marquee> 


   

    
    </body>
	</html>
	
		